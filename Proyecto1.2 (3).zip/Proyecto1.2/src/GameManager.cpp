#include "GameManager.h"
#include <iostream>

GameManager::GameManager(int rows,int columns):matrix(rows,columns){
    this->play=true;
    gameMode=-1;
}

void GameManager::menu(){

    int num;

    while(this->play){

        printf("Enter 1 for multiplayer\nEnter 2 to play against an ai\nEnter 3 to exit\n");
        scanf("%d",&num);
        setGameMode(num);
        printf("\n");

        if(this->gameMode==1){
            this->matrix.resetMatrix();
            multiplayerMode();
        }else if(this->gameMode==2){
            printf("Play against ai\n");
        }else if(this->gameMode==3){
            printf("Exiting the game\n");
            setPlay(false);
        }

    }

}

void GameManager::P1Move(){
   int col;
   printf("\n");
   printf("Enter the number of column\n");
   scanf("%d",&col);
   printf("\n");
   if(col>this->matrix.getColumns()){
    this->matrix.addColumn(col);
   }

   this->matrix.insertP1(col);
}

void GameManager::P2Move(){
    int col;
    printf("\n");
    printf("Enter the number of column\n");
    scanf("%d",&col);
    printf("\n");
    if(col>this->matrix.getColumns()){

        this->matrix.addColumn(col);
    }
    this->matrix.insertP2(col);
}

bool GameManager::winner(){

    int p1Count;
    int p2Count;

    //horizontal
    for(int i=0;i<this->matrix.getRows();i++){
        p1Count=0;
        p2Count=0;
        for(int j=0;j<this->matrix.getColumns();j++){
            if(this->matrix.getValue(i,j)==1){
                p1Count++;
                if(p1Count==4){
                    printf("Player 1 won the game!!\n\n");
                    return true;
                }
            }else{
                p1Count=0;
            }

            if(this->matrix.getValue(i,j)==2){
                p2Count++;
                if(p2Count==4){
                    printf("Player 2 won the game!!\n\n");
                    return true;
                }
            }else{
                p2Count=0;
            }
        }
    }

    //vertical
    for(int j=0;j<this->matrix.getColumns();j++){
        p1Count=0;
        p2Count=0;
        for(int i=0;i<this->matrix.getRows();i++){
            if(this->matrix.getValue(i,j)==1){
                p1Count++;
                if(p1Count==4){
                    printf("Player 1 won the game!!\n\n");
                    return true;
                }
            }else{
                p1Count=0;
            }

            if(this->matrix.getValue(i,j)==2){
                p2Count++;
                if(p2Count==4){
                    printf("Player 2 won the game!!\n\n");
                    return true;
                }
            }else{
                p2Count=0;
            }
        }

    }

    for(int i=0;i<this->matrix.getRows();i++){
        for(int j=0;j<this->matrix.getColumns();j++){

            if(this->matrix.getValue(i,j)==1){
                if(this->matrix.getRows()-3>i && this->matrix.getColumns()-3>j){
                    if(this->matrix.getValue(i+1,j+1)==1 && this->matrix.getValue(i+2,j+2)==1 && this->matrix.getValue(i+3,j+3)==1){
                        printf("Player 1 won the game!!\n\n");
                        return true;
                    }
                }

                if(this->matrix.getRows()-3>i && j-3>=0){
                    if(this->matrix.getValue(i+1,j-1)==1 && this->matrix.getValue(i+2,j-2)==1 && this->matrix.getValue(i+3,j-3)==1){
                        printf("Player 1 won the game!!\n\n");
                        return true;
                    }
                }

            }
            ////////
            if(this->matrix.getValue(i,j)==2){
                if(this->matrix.getRows()-3>i && this->matrix.getColumns()-3>j){
                    if(this->matrix.getValue(i+1,j+1)==2 && this->matrix.getValue(i+2,j+2)==2 && this->matrix.getValue(i+3,j+3)==2){
                        printf("Player 2 won the game!!\n\n");
                        return true;
                    }
                }
                if(this->matrix.getRows()-3>i && j-3>=0){
                    if(this->matrix.getValue(i+1,j-1)==2 && this->matrix.getValue(i+2,j-2)==2 && this->matrix.getValue(i+3,j-3)==2){
                        printf("Player 2 won the game!!\n\n");
                        return true;
                    }
                }

            }

        }
    }

    return false;
}

void GameManager::multiplayerMode(){

    this->matrix.printMatrix();

    while(true){
        P1Move();
        this->matrix.printMatrix();
        if(winner()){
            printf("Returning to the menu\n\n");
            break;
        }

        P2Move();
        this->matrix.printMatrix();
        if(winner()){
            printf("Returning to the menu\n\n");
            break;
        }
    }
}