#include<iostream>
#include"GameManager.cpp"

int main(){

    GameManager GameManager(6,7);
    GameManager.menu();

}