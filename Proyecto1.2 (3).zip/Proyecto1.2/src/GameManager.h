#ifndef PROJECT2_GAMEMANAGER_H
#define PROJECT2_GAMEMANAGER_H

#include "Matrix.cpp"

class GameManager{

private:

    bool play;
    int gameMode;
    Matrix matrix;

public:

    GameManager(int rows,int columns);
    inline void setPlay(bool newPlay){this->play=newPlay;}
    inline void setGameMode(int newGameMode){this->gameMode=newGameMode;}
    void menu();
    void multiplayerMode();
    void P1Move();
    void P2Move();
    bool winner();

};

#endif