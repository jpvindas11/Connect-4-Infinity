#include "GameManager.h"
#include <iostream>

GameManager::GameManager(int rows,int columns):matrix(rows,columns){
    this->play=true;
    gameMode=-1;
}

void GameManager::menu(){

    int num;

    while(this->play){
        
        printf("Enter 1 for multiplayer\nEnter 2 to play against an ai\nEnter 3 to exit\n");
        scanf("%d",&num);
        setGameMode(num);
        printf("\n");

        if(this->gameMode==1){
            this->matrix.resetMatrix();
            multiplayerMode();
        }else if(this->gameMode==2){
            this->matrix.resetMatrix();
            printf("Play against our giga AI\n");
            aiMode();
           
        }else if(this->gameMode==3){
            printf("Exiting the game\n");
            setPlay(false);
        }

    }

}

void GameManager::P1Move(){
   int col;
   printf("\n");
   printf("Enter the number of column\n");
   scanf("%d",&col);
   printf("\n");

   col=this->matrix.negativeColumn(col);
   if(col>this->matrix.getColumns()){

        this->matrix.addColumn(col,col,0,col);
    }
   this->matrix.insertP1(col);
}

void GameManager::P2Move(){
    int col;
    printf("\n");
    printf("Enter the number of column\n");
    scanf("%d",&col);
    printf("\n");

    col=this->matrix.negativeColumn(col);
    if(col>this->matrix.getColumns()){

        this->matrix.addColumn(col,col,0,col);
    }
    this->matrix.insertP2(col);
}
void GameManager::aiMove(){
    
    printf("\n");
    printf("AI is making a move");
    printf("\n");
    
    bool aiMoved = false;
    
    // caso base cuando el jugador hace el primer mov
    int singleRow = -1;
    int singleCol = -1;
    //se verifica si hay un solo 1 en la matriz
    for (int i = 0; i < this->matrix.getRows(); ++i) {
        for (int j = 0; j < this->matrix.getColumns(); ++j) {
            if (this->matrix.getValue(i, j) == 1) {
                if (singleRow == -1 && singleCol == -1) {
                    singleRow = i;
                    singleCol = j;
                } else {
                    // se encontro mas de un 1 entonces se sale y reinicia
                    singleRow = -1;
                    singleCol = -1;
                    break;
                }
            }
        }
    }

    // al haber solo un 1 entonces significa que es primer mov del jugador entonces la ia puede jugar donde quiera :)
    if (singleRow != -1 && singleCol != -1) {
        int randomColumn = rand() % (this->matrix.getColumns()); 
        this->matrix.insertP2(randomColumn);
        aiMoved = true;
        return;
    } else {
        // empieza a jugar defensivo a los movimientos del jugador
        for (int i = 0; i < this->matrix.getRows(); ++i) {
            for (int j = 0; j < this->matrix.getColumns(); ++j) {
                if (this->matrix.getValue(i, j) == 1 &&this->matrix.getValue(i, j+1) == 0){
                    int player1Col = j; 
                    this->matrix.insertP2(player1Col);
                    aiMoved = true;
                    break;
                }
                // horizontal
                else if (this->matrix.getValue(i, j) == 1 && this->matrix.getValue(i, j + 1) == 1) {
                    int player1Col = j; 
                    if (player1Col > 0 && player1Col < this->matrix.getColumns()) {
                        if (this->matrix.getValue(0, player1Col - 1) == 0) {
                            this->matrix.insertP2(player1Col - 1);
                            aiMoved = true;
                            break;
                
                        }
                        if (this->matrix.getValue(0, player1Col + 1) == 0) {
                            this->matrix.insertP2(player1Col + 1);
                            aiMoved = true;
                            break;
                        }
                    }else{
                        int col =this->matrix.negativeColumn(player1Col-1);
                        if(col>this->matrix.getColumns()){

                            this->matrix.addColumn(col,col,0,col);
                        }
                        this->matrix.insertP2(col);
                        aiMoved = true;
                        break;
                        
                    }
                
                
                    //vertical
                }else if (this->matrix.getValue(i, j) == 1 && this->matrix.getValue(i+1, j) == 1) {
                    int player1Col = j; 
                    this->matrix.insertP2(player1Col);
                    aiMoved = true;
                    break;
                }

                //diagonal
                else if(this->matrix.getValue(i,j)==1){
                    if(this->matrix.getRows()-3>i && this->matrix.getColumns()-3>j){
                        if(this->matrix.getValue(i+1,j+1)==1 && this->matrix.getValue(i+2,j+2)==1 && this->matrix.getValue(i+3,j+3)==0 && this->matrix.getValue(i+2,j+3)!=0){
                            this->matrix.insertP2(this->matrix.getValue(i+3,j+3));
                            aiMoved = true;
                            break;
                                
                                
                        }
                    }

                    if(this->matrix.getRows()-3>i && j-3>=0){
                        if(this->matrix.getValue(i+1,j-1)==1 && this->matrix.getValue(i+2,j-2)==1 && this->matrix.getValue(i+3,j-3)==0 && this->matrix.getValue(i+2,j-3)!=0){
                            this->matrix.insertP2(this->matrix.getValue(i+3,j-3));
                            aiMoved = true;
                            break;                 
                        }
                    }
                }

                
                if (aiMoved) {
                    return;
                }
            }
            if (aiMoved) {
                return;
            }
        }
    }

    // si no hubo mov
    if (!aiMoved) {
        int randomColumn = rand() % (this->matrix.getColumns()); 
        this->matrix.insertP2(randomColumn);
        aiMoved = true;
    }

    return;
}


bool GameManager::winner(){

    int p1Count;
    int p2Count;

    //horizontal
    for(int i=0;i<this->matrix.getRows();i++){
        p1Count=0;
        p2Count=0;
        for(int j=0;j<this->matrix.getColumns();j++){
            if(this->matrix.getValue(i,j)==1){
                p1Count++;
                if(p1Count==4){
                    printf("Player 1 won the game!!\n\n");
                    return true;
                }
            }else{
                p1Count=0;
            }

            if(this->matrix.getValue(i,j)==2){
                p2Count++;
                if(p2Count==4){
                    printf("Player 2 won the game!!\n\n");
                    return true;
                }
            }else{
                p2Count=0;
            }
        }
    }

    //vertical
    for(int j=0;j<this->matrix.getColumns();j++){
        p1Count=0;
        p2Count=0;
        for(int i=0;i<this->matrix.getRows();i++){
            if(this->matrix.getValue(i,j)==1){
                p1Count++;
                if(p1Count==4){
                    printf("Player 1 won the game!!\n\n");
                    return true;
                }
            }else{
                p1Count=0;
            }

            if(this->matrix.getValue(i,j)==2){
                p2Count++;
                if(p2Count==4){
                    printf("Player 2 won the game!!\n\n");
                    return true;
                }
            }else{
                p2Count=0;
            }
        }

    }

    for(int i=0;i<this->matrix.getRows();i++){
        for(int j=0;j<this->matrix.getColumns();j++){

            if(this->matrix.getValue(i,j)==1){
                if(this->matrix.getRows()-3>i && this->matrix.getColumns()-3>j){
                    if(this->matrix.getValue(i+1,j+1)==1 && this->matrix.getValue(i+2,j+2)==1 && this->matrix.getValue(i+3,j+3)==1){
                        printf("Player 1 won the game!!\n\n");
                        return true;
                    }
                }

                if(this->matrix.getRows()-3>i && j-3>=0){
                    if(this->matrix.getValue(i+1,j-1)==1 && this->matrix.getValue(i+2,j-2)==1 && this->matrix.getValue(i+3,j-3)==1){
                        printf("Player 1 won the game!!\n\n");
                        return true;
                    }
                }

            }
            ////////
            if(this->matrix.getValue(i,j)==2){
                if(this->matrix.getRows()-3>i && this->matrix.getColumns()-3>j){
                    if(this->matrix.getValue(i+1,j+1)==2 && this->matrix.getValue(i+2,j+2)==2 && this->matrix.getValue(i+3,j+3)==2){
                        printf("Player 2 won the game!!\n\n");
                        return true;
                    }
                }
                if(this->matrix.getRows()-3>i && j-3>=0){
                    if(this->matrix.getValue(i+1,j-1)==2 && this->matrix.getValue(i+2,j-2)==2 && this->matrix.getValue(i+3,j-3)==2){
                        printf("Player 2 won the game!!\n\n");
                        return true;
                    }
                }

            }

        }
    }

    return false;
}

void GameManager::multiplayerMode(){

    this->matrix.printMatrix();

    while(true){
        P1Move();
        this->matrix.printMatrix();
        if(winner()){
            printf("Returning to the menu\n\n");
            break;
        }

        P2Move();
        this->matrix.printMatrix();
        if(winner()){
            printf("Returning to the menu\n\n");
            break;
        }
    }
}
void GameManager::aiMode(){
    this->matrix.printMatrix();

    while(true){

        P1Move();
        int maxColumns = 10;
        if (this->matrix.getColumns() > maxColumns) {
            maxColumns = this->matrix.getColumns();
        }
        this->matrix.printMatrix();
        if(winner()){
            printf("Returning to the menu\n\n");
            break;
        }
        aiMove();
        this->matrix.printMatrix();
        if(winner()){
            printf("Returning to the menu\n\n");
            break;
        }
    }
};
