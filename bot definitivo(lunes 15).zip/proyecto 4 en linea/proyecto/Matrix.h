#ifndef Project1_Matrix_h
#define Project1_Matrix_h


class Matrix{

private:

    int rows;
    int columns;
    int firstColumn;

    int** matrix;

public:

    Matrix(int rows,int columns);
    void printMatrix();
    void addColumn(int newColumn,int colSign,int newColNum,int oldFC);
    void addRow(int newRow);
    void insertP1(int colNum);
    void insertP2(int colNum);
    int  FAR(int colNum);
    int negativeColumn(int colNum);
    inline void setRows(int newRows){this->rows=newRows;}
    inline void setColumns(int newColumns){this->columns=newColumns;}
    inline void setFirstColumn(int newFC){this->firstColumn=newFC;}
    inline int getFirstColumn(){return this->firstColumn;}
    inline int getRows(){return this->rows;}
    inline int getColumns(){return this->columns;}
    inline int getValue(int row,int col){return matrix[row][col];}
    void resetMatrix();
    ~Matrix();

};


#endif