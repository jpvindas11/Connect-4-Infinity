#include<iostream>
#include"GameManager.cpp"

int main(int argc, char *argv[]){

    GameManager GameManager(6,7);
    bool gameRun = true;

    while(gameRun == true){
        GameManager.update();
        gameRun = (GameManager.GameGraphics.isRunning);
    }

}