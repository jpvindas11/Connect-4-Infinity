#ifndef PROJECT2_GAMEMANAGER_H
#define PROJECT2_GAMEMANAGER_H

#include "Matrix.cpp"
#include "GameGraphics.cpp"

class GameManager{

private:

    bool play;
    int gameMode;
    int gameState;
    int a = 250;

    int drawPosX = 0; int drawPosY = 0;


    int turn;
    int input;
    int timer;
    bool drop;

public:

    Matrix matrix;
    GameGraphics GameGraphics;

    GameManager(int rows,int columns);
    inline void setPlay(bool newPlay){this->play=newPlay;}
    inline void setGameMode(int newGameMode){this->gameMode=newGameMode;}
    void update();
    void menu();
    void gameInput();
    void multiplayerMode();
    void aiMode();
    void P1Move();
    void P2Move();
    void aiMove();
    bool winner();

    void init();


};

#endif