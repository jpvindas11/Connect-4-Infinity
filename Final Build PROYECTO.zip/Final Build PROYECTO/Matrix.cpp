#include "iostream"
#include "Matrix.h"

Matrix::Matrix(int rows,int columns)
    : rows(rows), columns(columns) {

        this->matrix=(int **)malloc(rows * sizeof(int *));

        for(int i=0;i<rows;i++){
            this->matrix[i] = (int *)malloc(columns * sizeof(int));
        }

        for(int i=0;i<rows;i++){
            for(int j=0;j<columns;j++){
                this->matrix[i][j]=0;
            }
        }

        this->firstColumn=0;
}

Matrix::~Matrix(){

    for(int i=0;i<this->rows;i++){
    
        free(this->matrix[i]);

    }

    free(this->matrix);

}

void Matrix::printMatrix(){

    for(int i=0;i<this->rows;i++){
        for(int j=0;j<=this->columns;j++){
            printf("%i ",this->matrix[i][j]);
        }
        printf("\n");
    }
}


void Matrix::addColumn(int newColumn,int colSign,int newColNum,int oldFC){
    //puede ser que haya algo malo aqui jiji
    int newColsMax=newColumn+1;

    int **newMatrix=(int**)malloc(rows*sizeof(int*));

    for(int i=0;i<this->rows;i++){
        newMatrix[i]=(int*)malloc(newColsMax*sizeof(int));
    }

    if(abs(colSign>oldFC)){
        for(int i=0;i<this->getRows();i++){
            for(int j=0;j<=newColsMax;j++){
                if(j<newColNum){
                    newMatrix[i][j]=0;
                }else{
                    newMatrix[i][j]=matrix[i][j-newColNum];
                }
            }
        }
    }else{
        for(int i=0;i<this->rows;i++){

        for(int j=0;j<newColsMax;j++){

            if(j<=this->getColumns()){
                newMatrix[i][j]=matrix[i][j];
            }else{
                newMatrix[i][j]=0;
            }

        }
    }
    }


    for(int i=0;i<this->rows;i++){
        free(this->matrix[i]);
    }

    free(this->matrix);
    this->matrix=newMatrix;
    this->columns=newColsMax;

}

void Matrix::addRow(int newRow){
    int newRowMax=newRow;

    int **newMatrix=(int**)malloc(newRowMax*sizeof(int*));
    for(int i=0;i<newRowMax;i++){
        newMatrix[i]=(int*)malloc(this->columns*sizeof(int));
    }

    for(int i=newRowMax-1;i>=0;i--){
        for(int j=0;j<this->getColumns();j++){
            if(i>=this->getRows()){
                newMatrix[i][j]=matrix[i-1][j];
            }else{
                newMatrix[i][j]=0;
            }
        }
    }

    int numNewRows=newRowMax-this->getRows();

    for(int i=0;i<newRowMax;i++){
        for(int j=0;j<this->getColumns();j++){
            if(i<numNewRows){
                newMatrix[i][j]=0;
            }else{
                newMatrix[i][j]=matrix[i-numNewRows][j];
            }
        }
    }

    for(int i=0;i<this->rows;i++){
        free(this->matrix[i]);
    }

    free(this->matrix);
    this->matrix=newMatrix;
    this->rows=newRowMax;

}

int Matrix::FAR(int colNum){


    for(int i=this->rows-1;i>=0;i--){

        if(this->matrix[i][colNum]!=1 && this->matrix[i][colNum]!=2){
            return i;
        }
    }

    return -1;
}

void Matrix::insertP1(int colNum){

    int firstARow=FAR(colNum);

    if(firstARow==-1){
        this->addRow(this->getRows()+1);
        firstARow=FAR(colNum);
    }

    matrix[firstARow][colNum]=1;

}

void Matrix::insertP2(int colNum){
    

    int firstARow=FAR(colNum);

    if(firstARow==-1){
        this->addRow(this->getRows()+1);
        firstARow=FAR(colNum);
    }
    matrix[firstARow][colNum]=2;
}

void Matrix::resetMatrix(){

    this->setRows(6);
    this->setColumns(7);
    this->setFirstColumn(0);

    int** newMatrix=(int**)malloc(this->getRows()*sizeof(int*));
    for(int i=0;i<this->rows;i++){
        newMatrix[i]=(int*)malloc(this->getColumns()*sizeof(int));
    }

    for(int i=0;i<this->getRows();i++){
        for(int j=0;j<this->getColumns();j++){
            newMatrix[i][j]=0;
        }
    }

    for(int i=0;i<this->rows;i++){
        free(this->matrix[i]);
    }

    free(this->matrix);
    this->matrix=newMatrix;
}

int Matrix::negativeColumn(int colNum){

    int addToFC;
    int newColNum;

    if(colNum<0){


        colNum=abs(colNum);

        if(colNum>this->getFirstColumn()){
            int oldFC=this->getFirstColumn();

            newColNum=colNum-this->getFirstColumn();

            addToFC=colNum-this->getFirstColumn();

            this->setFirstColumn(this->getFirstColumn()+addToFC);

            this->addColumn(this->getColumns()+newColNum,colNum,newColNum,oldFC);

            return this->getFirstColumn()-colNum;

        }else{

            return this->getFirstColumn()-colNum;

        }
    }else{
        return colNum+this->getFirstColumn();
        
    }

}