#include "GameManager.h"
#include "sdl/SDL.h"
#include <iostream>


GameManager::GameManager(int rows,int columns):matrix(rows,columns){
    this->gameState = 0;
    this->play=true;
    this->input = 0;
    this->turn = 0;
    this->drop = false;
    gameMode=-1;
    init();
}

void GameManager::init(){
    this->GameGraphics.init();
}

void GameManager::update(){

    gameInput();

    //printf("%i",this->matrix.getColumns());

    if (gameState == 0){ //Menu
        menu();
    }
    else if(gameState > 0){ //Playing
        if (this->gameMode == 1){
            multiplayerMode();
        }
        if (this->gameMode == 2){
            aiMode();
        }
    }

    GameGraphics.update(gameState,this->gameMode,this->input, this-> turn, winner());
    GameGraphics.render(this->matrix.matrix,drawPosY,drawPosX, this->matrix.getFirstColumn());

    if (timer > 0){timer--;}

    //if (a > -1){a--;}
    //else {a=500;printf("posX: %i",drawPosX); printf("posY: %i",drawPosY); printf("R: %i",this->matrix.getRows()-6); printf("FC: %i",-this->matrix.getFirstColumn());printf("C: %i",this->matrix.getColumns()); printf("input: %i\n",input);}

}
void GameManager::menu(){

    if (drop == true){
        if (input == 0){ //PVP
            this->gameMode = 1;
        }
        else if (input == 1){ //BOT
            this->gameMode = 2;
        }
        gameState = 1;
        input = 0;
        this->matrix.resetMatrix();
        this->turn = 0;

        drawPosX = 0; drawPosY = 0;
        drop = false;
    }

}

void GameManager::gameInput(){

    SDL_Event keyInput;
    SDL_PollEvent(&keyInput);

    if(keyInput.type == SDL_KEYDOWN) //If key is held down
    {
        if (keyInput.key.keysym.sym == SDLK_RIGHT){
            input++;
        }
        if (keyInput.key.keysym.sym == SDLK_LEFT){
            input--;
        }
        if (keyInput.key.keysym.sym == SDLK_UP){
            if (drawPosY !=0)
            {
                drawPosY--;
            }
        }
        if (keyInput.key.keysym.sym == SDLK_DOWN){
            if (drawPosY != matrix.getRows()-6)
            {
                drawPosY++;
            }
        }
        if (keyInput.key.keysym.sym == SDLK_SPACE){
            if (drop == false){drop = true;}
        }
    }

    if (gameState==0){ //Is in menu
        if (input > 1){input = 1;}
        else if (input < 0){input = 0;}
    }
    if (gameState!=0){ //Is in game

        if (input < -this->matrix.getFirstColumn()-1){input = -this->matrix.getFirstColumn()-1;}
        if (input > this->matrix.getColumns()+1){input = this->matrix.getColumns()+1;}

        if ((input-3 < this->matrix.getColumns()-6) && (input-3>-this->matrix.getFirstColumn())){
            drawPosX = (input-3)+this->matrix.getFirstColumn();
        }
        else {

            if (input-3>=this->matrix.getColumns()-6){
                drawPosX = (this->matrix.getColumns()-6)+this->matrix.getFirstColumn();
            }
            if (input-3<= -this->matrix.getFirstColumn()){
                drawPosX = -this->matrix.getFirstColumn();
            }
        }
    }
}

void GameManager::P1Move(){

   int col=0;

   col = input;

   if (drop == true){
        col=this->matrix.negativeColumn(col);
        if(col>this->matrix.getColumns()){
            this->matrix.addColumn(col,col,0,col);
        }
        this->matrix.insertP1(col);
        this->turn = 1;
        drop = false;
        this->matrix.printMatrix();
   }
}

void GameManager::P2Move(){
    int col=0;

    col = input;

    if (drop == true){
        col=this->matrix.negativeColumn(col);
        if(col>this->matrix.getColumns()){
            this->matrix.addColumn(col,col,0,col);
        }
        this->matrix.insertP2(col);
        this->turn = 0;
        drop = false;
        this->matrix.printMatrix();
    }
}
void GameManager::aiMove(){
    
    printf("\n");
    printf("AI is making a move");
    printf("\n");
    
    bool aiMoved = false;
    
    // caso base cuando el jugador hace el primer mov
    int singleRow = -1;
    int singleCol = -1;
    //se verifica si hay un solo 1 en la matriz
    for (int i = 0; i < this->matrix.getRows(); ++i) {
        for (int j = 0; j < this->matrix.getColumns(); ++j) {
            if (this->matrix.getValue(i, j) == 1) {
                if (singleRow == -1 && singleCol == -1) {
                    singleRow = i;
                    singleCol = j;
                } else {
                    // se encontro mas de un 1 entonces se sale y reinicia
                    singleRow = -1;
                    singleCol = -1;
                    break;
                }
            }
        }
    }

    // al haber solo un 1 entonces significa que es primer mov del jugador entonces la ia puede jugar donde quiera :)
    if (singleRow != -1 && singleCol != -1) {
        int randomColumn = rand() % (this->matrix.getColumns()); 
        this->matrix.insertP2(randomColumn);
        aiMoved = true;
        this->turn = 0;
        this->matrix.printMatrix();
        return;
    } else {
        // empieza a jugar defensivo a los movimientos del jugador
        for (int i = 0; i < this->matrix.getRows(); ++i) {
            for (int j = 0; j < this->matrix.getColumns(); ++j) {
                if (this->matrix.getValue(i, j) == 1 &&this->matrix.getValue(i, j+1) == 0){
                    int player1Col = j; 
                    this->matrix.insertP2(player1Col);
                    aiMoved = true;
                    break;
                }
                // horizontal
                else if (this->matrix.getValue(i, j) == 1 && this->matrix.getValue(i, j + 1) == 1) {
                    int player1Col = j; 
                    if (player1Col > 0 && player1Col < this->matrix.getColumns()) {

                        if (this->matrix.getValue(i, player1Col + 2) == 0) {
                            this->matrix.insertP2(player1Col+2 );
                            aiMoved = true;
                            break;
                        }
                        if (this->matrix.getValue(i, player1Col - 1) == 0) {
                            this->matrix.insertP2(player1Col - 1);
                            aiMoved = true;
                            break;
                
                        }
                    }else{
                        int col =this->matrix.negativeColumn(player1Col-1);
                        if(col>this->matrix.getColumns()){

                            this->matrix.addColumn(col,col,0,col);
                        }
                        this->matrix.insertP2(col);
                        aiMoved = true;
                        break;
                        
                    }
                
                
                    //vertical
                }else if (this->matrix.getValue(i, j) == 1 && this->matrix.getValue(i+1, j) == 1) {
                    int player1Col = j; 
                    this->matrix.insertP2(player1Col);
                    aiMoved = true;
                    break;
                }

                //diagonal
                else if(this->matrix.getValue(i,j)==1){
                    if(this->matrix.getRows()-3>i && this->matrix.getColumns()-3>j){
                        if(this->matrix.getValue(i+1,j+1)==1 && this->matrix.getValue(i+2,j+2)==1 && this->matrix.getValue(i+3,j+3)==0 && this->matrix.getValue(i+2,j+3)!=0){
                            this->matrix.insertP2(this->matrix.getValue(i+3,j+3));
                            aiMoved = true;
                            break;
                                
                                
                        }
                    }

                    if(this->matrix.getRows()-3>i && j-3>=0){
                        if(this->matrix.getValue(i+1,j-1)==1 && this->matrix.getValue(i+2,j-2)==1 && this->matrix.getValue(i+3,j-3)==0 && this->matrix.getValue(i+2,j-3)!=0){
                            this->matrix.insertP2(this->matrix.getValue(i+3,j-3));
                            aiMoved = true;
                            break;                 
                        }
                    }
                }

                
                if (aiMoved) {
                    this->turn = 0;
                    this->matrix.printMatrix();
                    return;
                }
            }
            if (aiMoved) {
                this->turn = 0;
                this->matrix.printMatrix();
                return;
            }
        }
    }

    // si no hubo mov
    if (!aiMoved) {
        int randomColumn = rand() % (this->matrix.getColumns()); 
        this->matrix.insertP2(randomColumn);
        aiMoved = true;
    }
    this->turn = 0;
    this->matrix.printMatrix();
    return;
}


bool GameManager::winner(){

    int p1Count;
    int p2Count;

    //horizontal
    for(int i=0;i<this->matrix.getRows();i++){
        p1Count=0;
        p2Count=0;
        for(int j=0;j<this->matrix.getColumns();j++){
            if(this->matrix.getValue(i,j)==1){
                p1Count++;
                if(p1Count==4){
                    printf("Player 1 won the game!!\n\n");
                    return true;
                }
            }else{
                p1Count=0;
            }

            if(this->matrix.getValue(i,j)==2){
                p2Count++;
                if(p2Count==4){
                    printf("Player 2 won the game!!\n\n");
                    return true;
                }
            }else{
                p2Count=0;
            }
        }
    }

    //vertical
    for(int j=0;j<this->matrix.getColumns();j++){
        p1Count=0;
        p2Count=0;
        for(int i=0;i<this->matrix.getRows();i++){
            if(this->matrix.getValue(i,j)==1){
                p1Count++;
                if(p1Count==4){
                    printf("Player 1 won the game!!\n\n");
                    return true;
                }
            }else{
                p1Count=0;
            }

            if(this->matrix.getValue(i,j)==2){
                p2Count++;
                if(p2Count==4){
                    printf("Player 2 won the game!!\n\n");
                    return true;
                }
            }else{
                p2Count=0;
            }
        }

    }

    for(int i=0;i<this->matrix.getRows();i++){
        for(int j=0;j<this->matrix.getColumns();j++){

            if(this->matrix.getValue(i,j)==1){
                if(this->matrix.getRows()-3>i && this->matrix.getColumns()-3>j){
                    if(this->matrix.getValue(i+1,j+1)==1 && this->matrix.getValue(i+2,j+2)==1 && this->matrix.getValue(i+3,j+3)==1){
                        printf("Player 1 won the game!!\n\n");
                        return true;
                    }
                }

                if(this->matrix.getRows()-3>i && j-3>=0){
                    if(this->matrix.getValue(i+1,j-1)==1 && this->matrix.getValue(i+2,j-2)==1 && this->matrix.getValue(i+3,j-3)==1){
                        printf("Player 1 won the game!!\n\n");
                        return true;
                    }
                }

            }
            ////////
            if(this->matrix.getValue(i,j)==2){
                if(this->matrix.getRows()-3>i && this->matrix.getColumns()-3>j){
                    if(this->matrix.getValue(i+1,j+1)==2 && this->matrix.getValue(i+2,j+2)==2 && this->matrix.getValue(i+3,j+3)==2){
                        printf("Player 2 won the game!!\n\n");
                        return true;
                    }
                }
                if(this->matrix.getRows()-3>i && j-3>=0){
                    if(this->matrix.getValue(i+1,j-1)==2 && this->matrix.getValue(i+2,j-2)==2 && this->matrix.getValue(i+3,j-3)==2){
                        printf("Player 2 won the game!!\n\n");
                        return true;
                    }
                }

            }

        }
    }

    return false;
}

void GameManager::multiplayerMode(){
    
    if (winner() == false){
        if (this->turn==0){
            P1Move();
        }
        else if (this->turn==1){
            P2Move();
        }
        timer = 1000;
    }
    else if (winner() == true){
        if (timer == 0){
            gameState = 0;
            input = 0;
        }
    }
}
void GameManager::aiMode(){

    int maxColumns = 10;
    if (winner() == false){
        if (this->turn==0){
            P1Move();
        }
        else if (this->turn==1){
            aiMove();
        }
        timer = 1000;
    }
    else if (winner() == true){
        if (timer == 0){
            gameState = 0;
            input = 0;
        }

    }
}
