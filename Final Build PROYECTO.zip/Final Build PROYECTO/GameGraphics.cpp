#include<sdl/SDL.h>
#include<sdl/SDL_image.h>
#include<iostream>

class GameGraphics{

    public:
        SDL_Renderer *renderer = nullptr;
        SDL_Window *window = nullptr;

        SDL_Texture* gameBoard;
        SDL_Texture* playerCoinRed; 
        SDL_Texture* playerCoinYellow; 
        SDL_Texture* buttonPvP; SDL_Texture* buttonPvPC;
        SDL_Texture* buttonAI; SDL_Texture* buttonAIC;
        SDL_Texture* title; 
        SDL_Texture* p1Won; SDL_Texture* p2Won;

        SDL_Texture* bgBlue; SDL_Texture* bgGreen; SDL_Texture* bgPink;

        SDL_Rect desR, boardR, titleR, buttonAIR, buttonPvPR, playerR, wonR;

        bool isRunning; bool gameWon;
        int gameState = 0; int input = 0;
        int gameMode = 0; int turn = 0;

    void init(){
        if (SDL_Init(SDL_INIT_EVERYTHING) == 0){

            window = SDL_CreateWindow("Connect 4",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,800,600,SDL_WINDOW_SHOWN);
            renderer = SDL_CreateRenderer(window,-1,0);
            SDL_SetRenderDrawColor(renderer,255,255,255,255);

            gameBoard = LoadTexture("sprites/board.png",renderer);
            playerCoinRed = LoadTexture("sprites/red_coin.png",renderer);
            playerCoinYellow = LoadTexture("sprites/yellow_coin.png",renderer);
            buttonAI = LoadTexture("sprites/button_ia.png",renderer);
            buttonPvP = LoadTexture("sprites/button_pvp.png",renderer);
            buttonAIC = LoadTexture("sprites/button_ia_selected.png",renderer);
            buttonPvPC = LoadTexture("sprites/button_pvp_selected.png",renderer);
            title = LoadTexture("sprites/title.png",renderer);
            bgBlue = LoadTexture("sprites/bg_blue.png",renderer);
            bgGreen = LoadTexture("sprites/bg_green.png",renderer);
            bgPink = LoadTexture("sprites/bg_pink.png",renderer);
            p1Won = LoadTexture("sprites/p1_won.png",renderer);
            p2Won = LoadTexture("sprites/p2_won.png",renderer);

            desR.h = 48; desR.w = 48; desR.x = -48; desR.y = -48;
            playerR.h = 48; playerR.w = 48;
            boardR.h = 288; boardR.w = 336; boardR.x = -1000; boardR.y = -1000;

            isRunning = true;
        }
    }

    void update(int gameStateP, int gameModeP, int inputP, int turnP, bool gameWonP){

        gameState = gameStateP; gameMode = gameModeP;
        input = inputP; turn = turnP; gameWon = gameWonP;

        SDL_Event event;
        SDL_PollEvent(&event);

        if (SDL_QUIT == event.type){
            isRunning = false;
        }
    }

    void render(int** matrix,int drawPosY, int drawPosX, int posEx){

        SDL_RenderClear(renderer);

        //Background
        if (gameState==0){SDL_RenderCopy(renderer, bgBlue, NULL,NULL);}
        else {
            if (gameMode==1){SDL_RenderCopy(renderer, bgPink, NULL,NULL);}
            else SDL_RenderCopy(renderer, bgGreen, NULL,NULL);
        }

        if (gameState==0){ //menu
            titleR.w = 512; titleR.h = 256;
            titleR.x = 144; titleR.y = 48;

            buttonPvPR.w = 256; buttonPvPR.h = 128;
            buttonPvPR.x = 96; buttonPvPR.y = 384;

            buttonAIR.w = 256; buttonAIR.h = 128;
            buttonAIR.x = 432; buttonAIR.y = 384;

            desR.h = 48; desR.w = 48; desR.x = -48; desR.y = -48;
            wonR.x = -1000; wonR.y = -1000;

            SDL_RenderCopy(renderer, title, NULL, &titleR);

            if (input == 0){
                SDL_RenderCopy(renderer, buttonPvPC, NULL, &buttonPvPR);
                SDL_RenderCopy(renderer, buttonAI, NULL, &buttonAIR);
            }
            else if (input == 1){
                SDL_RenderCopy(renderer, buttonPvP, NULL, &buttonPvPR);
                SDL_RenderCopy(renderer, buttonAIC, NULL, &buttonAIR);
            }
        }
        if (gameState !=0){ //game

            titleR.x = -1000; titleR.y = -1000;
            buttonPvPR.x = -1000; buttonPvPR.y = -1000;
            buttonAIR.x = -1000; buttonAIR.y = -1000;

            wonR.w = 512; wonR.h = 256;
            wonR.x = 144; wonR.y = 336;

            for (int i = drawPosY; i < drawPosY+6; i++) { //Matrix
                for (int j = drawPosX; j < drawPosX+7; j++) {
                    if (matrix[i][j] == 1) {
                        desR.x = ((48 * (j + 2))+130)-48*drawPosX;
                        desR.y = ((48 * (i + 2))+96)-48*drawPosY;
                        SDL_RenderCopy(renderer, playerCoinYellow, NULL, &desR);
                    }
                    if (matrix[i][j] == 2) {
                        desR.x = ((48 * (j + 2))+130)-48*drawPosX;
                        desR.y = ((48 * (i + 2))+96)-48*drawPosY;
                        SDL_RenderCopy(renderer, playerCoinRed, NULL, &desR);
                    }
                    if (i == 0 && j == input){
                        playerR.x = ((48 * (j + 2))+130)-48*(drawPosX-posEx);
                        playerR.y = 124;
                    }
                }
            }
            //Player POS
            boardR.x = 226; boardR.y = 192;

            if (turn == 0){
                SDL_RenderCopy(renderer, playerCoinYellow, NULL, &playerR);
            }
            else if (turn == 1){
                SDL_RenderCopy(renderer, playerCoinRed, NULL, &playerR);
            }

            //Board
            SDL_RenderCopy(renderer, gameBoard, NULL, &boardR);

            //Win sign
            if (gameWon == true){
                if (turn == 1){
                    SDL_RenderCopy(renderer, p1Won, NULL, &wonR);
                }
                else if (turn == 0){
                    SDL_RenderCopy(renderer, p2Won, NULL, &wonR);
                }
            }
        
        }

        SDL_RenderPresent(renderer);
    }

    SDL_Texture* LoadTexture(const char* texture, SDL_Renderer *ren){
        SDL_Surface* tempSurf = IMG_Load(texture);
        SDL_Texture* tex = SDL_CreateTextureFromSurface(ren, tempSurf);
        SDL_FreeSurface(tempSurf);

        return tex;
    }

    bool running(){
        return isRunning;
    }

    void destroy(){
        SDL_DestroyWindow (window);
        SDL_Quit();
    }
};